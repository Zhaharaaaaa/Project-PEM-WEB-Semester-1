    <!-- hero -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-box d-flex align-items-center justify-content-between flex-md-row flex-column">
                <div class="box">
                    <h1> Selamat datang <br> di web <span>Konveru</span></h1>
                    <p>Konveru adalah website menghitung ukuran data <br>
                       dengan konveru diharapkan dapat membantu pekerjaan anda</p>
                       <div>
                        <a href="index.php?hal=konversi" class="btn">Konversi</a>
                       </div>
                </div>
            </div>
        </div>
     </section>