    <!-- Team menggunakan bootstrap card images-->
    <section class="team-section" id="about">
         <div class="container">
            <div class="team-box text-center ">
                <h1 class="mb-2" data-aos="fade-up" data-aos-duration="1000">Team us</h1>
                <p class="lh-lg" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="300">Hallo kami pengembang aplikasi Konveru ini, kami mahasiswa Sekolah Tinggi Teknologi Terpadu Nurul fikri
                                        kami adalah mahasiswa dari prodi sistem informasi angkatan 2024
                </p>
                    <div class="card-group">
                        <div class="card rounded bg-light bg-opacity-75" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
                          <img src="./img/fadil.png" class="card-img-top rounded-circle" alt="foto">
                          <div class="card-body">
                            <h4 class="card-title"> Muhammad Fadhil </h4>
                            <p class="card-text"> bukan aku yang hebat tapi doa ibuku yang kuat✨. </p>
                            <p class="card-text"><small class="text-body-secondary"> 0110124094 - Member </small></p>
                          </div>
                        </div>
                        <div class="card rounded bg-light bg-opacity-75" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="700">
                          <img src="./img/jara.png" class="card-img-top rounded-circle" alt="foto">
                          <div class="card-body">
                            <h4 class="card-title">Zhahara N Sukirman</h4>
                            <p class="card-text">Bermimpi menjadi seorang desainer grafis yang profesional.</p>
                            <p class="card-text"><small class="text-body-secondary">0110124206 - Head</small></p>
                          </div>
                        </div>
                        <div class="card rounded bg-light bg-opacity-75" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="900">
                          <img src="./img/bayu.png" class="card-img-top rounded-circle" alt="foto">
                          <div class="card-body">
                            <h4 class="card-title">M Bayu Anggara</h4>
                            <p class="card-text">saya seorang  mahasiswa sistém informasi yang  sudah ahli dalam mencari alasan untuk menunda tugas tapi selesai dengan waktu yang pas.</p>
                            <p class="card-text"><small class="text-body-secondary"> 0110124178 - Member</small></p>
                          </div>
                        </div>
                      </div>
            </div>
         </div>
     </section>